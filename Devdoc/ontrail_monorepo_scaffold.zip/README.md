
# OnTrail Monorepo

Web3 Social‑Fi platform for runners, hikers and explorers.

## Structure

apps/
  web/      → Vite + React frontend
  mobile/   → Expo React Native app

services/
  api/      → FastAPI business logic
  data/     → FastAPI secure database gateway

contracts/
  Solidity smart contracts

infra/
  nginx + pm2 configs

scripts/
  database setup and migrations
