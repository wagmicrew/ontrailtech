
import React from "react"
import ReactDOM from "react-dom/client"

function App() {
  return (
    <div>
      <h1>OnTrail</h1>
      <p>Explore. Run. Own the trail.</p>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />)
