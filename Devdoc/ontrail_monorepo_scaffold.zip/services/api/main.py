
from fastapi import FastAPI

app = FastAPI(title="OnTrail API")

@app.get("/health")
def health():
    return {"status":"ok"}
