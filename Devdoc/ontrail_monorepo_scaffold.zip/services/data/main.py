
from fastapi import FastAPI
import psycopg2

app = FastAPI(title="OnTrail Data Gateway")

@app.get("/health")
def health():
    return {"status":"data-ok"}
