
module.exports = {
 apps : [
   {
     name: "api",
     script: "services/api/main.py"
   }
 ]
}
