
pragma solidity ^0.8.0;

contract POI {
    struct Point {
        string name;
        string location;
        address owner;
    }

    Point[] public pois;
}
