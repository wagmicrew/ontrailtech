
pragma solidity ^0.8.0;

contract RunnerToken {

    string public name = "RunnerToken";
    string public symbol = "RUN";

}
