
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT,
  wallet TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pois (
  id SERIAL PRIMARY KEY,
  name TEXT,
  latitude FLOAT,
  longitude FLOAT,
  owner_id INT
);
