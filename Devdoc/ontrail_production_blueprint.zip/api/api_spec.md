
# OnTrail API Specification

## Auth
POST /auth/login

## Users
GET /users/{id}
POST /users

## POI
GET /poi/nearby
POST /poi/mint

## Checkins
POST /checkin

## Runner Tokens
POST /token/buy
POST /token/sell
GET /token/{runner}

## Admin
GET /admin/config
POST /admin/config
