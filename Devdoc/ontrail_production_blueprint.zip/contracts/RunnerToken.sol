
pragma solidity ^0.8.0;

contract RunnerToken {

    string public name;
    string public symbol;
    uint public totalSupply;

    mapping(address => uint) public balanceOf;

    constructor(string memory _name, string memory _symbol) {
        name = _name;
        symbol = _symbol;
    }
}
