
pragma solidity ^0.8.0;

contract BondingCurve {

    uint public basePrice = 1e15;

    function price(uint supply) public view returns(uint) {
        return basePrice + (supply * supply * 1e12);
    }
}
