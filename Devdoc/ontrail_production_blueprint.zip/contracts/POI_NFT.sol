
pragma solidity ^0.8.0;

contract POINFT {

    struct POI {
        string name;
        string location;
        address owner;
    }

    POI[] public pois;

    function mint(string memory name, string memory location) public {
        pois.push(POI(name, location, msg.sender));
    }
}
