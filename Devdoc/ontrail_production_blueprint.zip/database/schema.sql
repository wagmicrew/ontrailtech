
CREATE TABLE users (
 id SERIAL PRIMARY KEY,
 username TEXT UNIQUE,
 email TEXT,
 wallet_address TEXT,
 role TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pois (
 id SERIAL PRIMARY KEY,
 name TEXT,
 latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION,
 rarity TEXT,
 owner_id INT REFERENCES users(id),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE checkins (
 id SERIAL PRIMARY KEY,
 user_id INT REFERENCES users(id),
 poi_id INT REFERENCES pois(id),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE runner_tokens (
 id SERIAL PRIMARY KEY,
 runner_id INT REFERENCES users(id),
 contract_address TEXT,
 supply INT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE friend_shares (
 id SERIAL PRIMARY KEY,
 owner_id INT REFERENCES users(id),
 runner_id INT REFERENCES users(id),
 amount INT
);

CREATE TABLE token_pools (
 id SERIAL PRIMARY KEY,
 runner_token_id INT REFERENCES runner_tokens(id),
 liquidity FLOAT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE steps (
 id SERIAL PRIMARY KEY,
 user_id INT REFERENCES users(id),
 step_count INT,
 recorded_at TIMESTAMP
);

CREATE TABLE acl_roles (
 id SERIAL PRIMARY KEY,
 name TEXT,
 permissions JSONB
);

CREATE TABLE translations (
 id SERIAL PRIMARY KEY,
 locale TEXT,
 key TEXT,
 value TEXT
);
